To launch the application run start.cmd

This is an java application Requires JVM 1.8 to run.

Requires a dictionary file with each line containing a single word , use the words.txt file in this directory for testing or create a new file or download from link : http://codekata.com/data/wordlist.txt
